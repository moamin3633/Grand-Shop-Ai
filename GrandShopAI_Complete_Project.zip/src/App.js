import React from 'react';
import Header from './components/Header';

function App() {
  return (
    <div className="App">
      <Header />
      <main className="p-4">
        <h1 className="text-3xl font-bold">Welcome to Grand Shop AI</h1>
        <p>Smart Product Discovery | Auto-import from Amazon & More</p>
      </main>
    </div>
  );
}

export default App;
