import React from 'react';

function Header() {
  return (
    <header className="bg-black text-gold p-4 flex justify-between items-center">
      <h1 className="text-xl font-bold">Grand Shop AI</h1>
      <div>
        <button className="bg-gold text-black px-3 py-1 rounded">Search</button>
      </div>
    </header>
  );
}

export default Header;
